---
layout: archive
title: "Research Projects"
permalink: /portfolio/
author_profile: true
---

{% include base_path %}

{% for post in site.portfolio %}
  {% include archive-single.html type="grid" %}
{% endfor %}
